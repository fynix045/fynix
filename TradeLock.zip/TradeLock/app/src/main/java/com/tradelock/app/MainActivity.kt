package com.tradelock.app

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

object Ui {
    val rev = mutableIntStateOf(0)
    fun bump() { rev.intValue = rev.intValue + 1 }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        Ui.bump()
    }
}

@Composable
fun App() {
    val rev = Ui.rev.intValue
    var tab by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = tab) {
            listOf("Dashboard", "Manage Apps", "Settings").forEachIndexed { i, t ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) })
            }
        }
        when (tab) {
            0 -> Dashboard(rev)
            1 -> ManageApps(rev)
            else -> SettingsTab(rev)
        }
    }
}

@Composable
fun Dashboard(rev: Int) {
    val c = LocalContext.current
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(1000) } }
    val lock = remember(now, rev) { Engine.current(c) }
    val a11y = Engine.a11yOn(c)
    val apps = Store.apps(c)
    val active = a11y && apps.any { it.enabled }
    val (loss, trades) = Engine.stats(c)
    var consent by remember { mutableStateOf(false) }
    var emerg by remember { mutableStateOf(false) }
    var amount by remember { mutableStateOf("") }

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(colors = CardDefaults.cardColors(containerColor = if (active) Color(0xFF14532D) else Color(0xFF7F1D1D))) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(if (active) "PROTECTION ACTIVE" else "PROTECTION INACTIVE", fontWeight = FontWeight.Bold)
                if (!a11y) {
                    Text("Accessibility Service is off. Protected apps are NOT blocked.")
                    Button(onClick = { consent = true }) { Text("Enable protection") }
                } else if (!active) {
                    Text("No protected app is enabled. Check Manage Apps.")
                }
            }
        }
        Card {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                if (lock != null) {
                    Text("LOCK ACTIVE", fontWeight = FontWeight.Bold, color = Color(0xFFFF5252))
                    Text("Reason: ${lock.reason}")
                    Text("Remaining: ${Engine.fmt(lock.endMs - now)}", fontSize = 20.sp)
                } else {
                    Text("No active lock", fontWeight = FontWeight.Bold)
                }
            }
        }
        Card {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Today", fontWeight = FontWeight.Bold)
                Text("Loss: ${"%.2f".format(loss)} / ${Store.num(c, "lossLimit", 100.0)}")
                Text("Trades: $trades / ${Store.int(c, "maxTrades", 3)}")
            }
        }
        Card {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Log trade result", fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = amount, onValueChange = { amount = it },
                    label = { Text("Loss amount (positive number)") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        val v = amount.replace(',', '.').toDoubleOrNull()
                        if (v == null || v <= 0) {
                            Toast.makeText(c, "Enter a positive loss amount", Toast.LENGTH_SHORT).show()
                        } else {
                            Engine.logTrade(c, v); amount = ""; Ui.bump()
                        }
                    }) { Text("Log Loss") }
                    OutlinedButton(onClick = { Engine.logTrade(c, 0.0); Ui.bump() }) { Text("Log Win") }
                }
            }
        }
        Button(
            onClick = { emerg = true },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB91C1C)),
            modifier = Modifier.fillMaxWidth()
        ) { Text("Emergency Lock") }
        Text(
            "Note: blocking the app does not close open positions or stop running EAs. " +
                "The lock can still be bypassed by turning off the Accessibility Service or uninstalling TRADELOCK.",
            fontSize = 12.sp
        )
    }

    if (consent) {
        AlertDialog(
            onDismissRequest = { consent = false },
            title = { Text("Accessibility permission") },
            text = {
                Text(
                    "TRADELOCK uses the Accessibility Service only to detect which app is in the foreground, " +
                        "so it can show the lock screen for protected apps while a lockdown is active. " +
                        "It does not read screen content, keystrokes or personal data, and nothing leaves your device."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    consent = false
                    c.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }) { Text("I agree, open settings") }
            },
            dismissButton = { TextButton(onClick = { consent = false }) { Text("Cancel") } }
        )
    }
    if (emerg) {
        AlertDialog(
            onDismissRequest = { emerg = false },
            title = { Text("Emergency Lock") },
            text = {
                Column {
                    Text("This cannot be cancelled once started.")
                    TextButton(onClick = { Engine.emergency(c, 60); emerg = false; Ui.bump() }) { Text("Lock 1 hour") }
                    TextButton(onClick = { Engine.emergency(c, 240); emerg = false; Ui.bump() }) { Text("Lock 4 hours") }
                    TextButton(onClick = { Engine.emergency(c, null); emerg = false; Ui.bump() }) { Text("Lock until end of day") }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { emerg = false }) { Text("Back") } }
        )
    }
}

@Composable
fun ManageApps(rev: Int) {
    val c = LocalContext.current
    val locked = Engine.current(c) != null
    val apps = Store.apps(c)
    var adding by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf<Store.PApp?>(null) }

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (locked) Text("Locked: the protected list can't be changed until the lock ends.", color = Color(0xFFFFB4AB))
        apps.forEach { a ->
            Card {
                Column(Modifier.padding(12.dp)) {
                    Text(a.name, fontWeight = FontWeight.Bold)
                    Text(a.pkg, fontSize = 11.sp)
                    Text("Status: ${Engine.appStatus(c, a.pkg)}  |  Protection ${if (a.enabled) "ON" else "OFF"}", fontSize = 13.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(
                            checked = a.enabled, enabled = !locked,
                            onCheckedChange = { v ->
                                Store.setApps(c, apps.map { if (it.pkg == a.pkg) it.copy(enabled = v) else it })
                                Ui.bump()
                            }
                        )
                        Spacer(Modifier.weight(1f))
                        TextButton(enabled = !locked, onClick = { renaming = a }) { Text("Rename") }
                        TextButton(enabled = !locked, onClick = {
                            Store.setApps(c, apps.filter { it.pkg != a.pkg }); Ui.bump()
                        }) { Text("Remove") }
                    }
                }
            }
        }
        Button(enabled = !locked, onClick = { adding = true }) { Text("+ Add Trading App") }
    }

    if (adding) {
        val pm = c.packageManager
        val have = apps.map { it.pkg }.toSet()
        val list = remember {
            pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
                .distinctBy { it.first }
                .sortedBy { it.second.lowercase() }
        }
        var sel by remember { mutableStateOf<Pair<String, String>?>(null) }
        AlertDialog(
            onDismissRequest = { adding = false },
            title = { Text("Select app to protect") },
            text = {
                LazyColumn(Modifier.heightIn(max = 380.dp)) {
                    items(list.filter { it.first !in have && it.first != c.packageName }) { p ->
                        Row(
                            Modifier.fillMaxWidth().clickable { sel = p }.padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = sel == p, onClick = { sel = p })
                            Column {
                                Text(p.second)
                                Text(p.first, fontSize = 11.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(enabled = sel != null, onClick = {
                    sel?.let { Store.setApps(c, apps + Store.PApp(it.first, it.second, true)) }
                    adding = false; Ui.bump()
                }) { Text("Add") }
            },
            dismissButton = { TextButton(onClick = { adding = false }) { Text("Cancel") } }
        )
    }
    renaming?.let { target ->
        var name by remember(target.pkg) { mutableStateOf(target.name) }
        AlertDialog(
            onDismissRequest = { renaming = null },
            title = { Text("Display name") },
            text = { OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    if (name.isNotBlank()) {
                        Store.setApps(c, apps.map { if (it.pkg == target.pkg) it.copy(name = name.trim()) else it })
                    }
                    renaming = null; Ui.bump()
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { renaming = null }) { Text("Cancel") } }
        )
    }
}

@Composable
fun SettingsTab(rev: Int) {
    val c = LocalContext.current
    val locked = Engine.current(c) != null
    var loss by remember(rev) { mutableStateOf(Store.num(c, "lossLimit", 100.0).toString()) }
    var maxT by remember(rev) { mutableStateOf(Store.int(c, "maxTrades", 3).toString()) }
    var cool by remember(rev) { mutableStateOf(Store.int(c, "cooldownMin", 60).toString()) }
    var hs by remember(rev) { mutableStateOf(Store.int(c, "hStart", 20).toString()) }
    var he by remember(rev) { mutableStateOf(Store.int(c, "hEnd", 4).toString()) }
    var zone by remember(rev) { mutableStateOf(Store.str(c, "zone", "Asia/Jakarta")) }
    var tLoss by remember(rev) { mutableStateOf(Store.bool(c, "tLoss", true)) }
    var tTrades by remember(rev) { mutableStateOf(Store.bool(c, "tTrades", true)) }
    var tCool by remember(rev) { mutableStateOf(Store.bool(c, "tCooldown", true)) }
    var tHours by remember(rev) { mutableStateOf(Store.bool(c, "tHours", false)) }

    @Composable
    fun Field(label: String, v: String, onChange: (String) -> Unit) {
        OutlinedTextField(
            value = v, onValueChange = onChange, label = { Text(label) },
            singleLine = true, enabled = !locked, modifier = Modifier.fillMaxWidth()
        )
    }

    @Composable
    fun Trig(label: String, v: Boolean, onChange: (Boolean) -> Unit) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, Modifier.weight(1f))
            Switch(checked = v, onCheckedChange = onChange, enabled = !locked)
        }
    }

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (locked) Text("Locked: settings are frozen until the lock ends.", color = Color(0xFFFFB4AB))
        Text("Risk limits", fontWeight = FontWeight.Bold)
        Field("Daily loss limit", loss) { loss = it }
        Field("Max trades per day", maxT) { maxT = it }
        Field("Cooldown after loss (minutes)", cool) { cool = it }
        Text("Trading hours (0-23, wraps past midnight)", fontWeight = FontWeight.Bold)
        Field("Start hour", hs) { hs = it }
        Field("End hour", he) { he = it }
        Field("Time zone (e.g. Asia/Jakarta)", zone) { zone = it }
        Text("Lockdown triggers", fontWeight = FontWeight.Bold)
        Trig("Daily loss limit reached", tLoss) { tLoss = it }
        Trig("Daily trade limit reached", tTrades) { tTrades = it }
        Trig("Cooldown after loss", tCool) { tCool = it }
        Trig("Outside trading hours", tHours) { tHours = it }
        Text("Emergency Lock is always available from the Dashboard.", fontSize = 12.sp)
        Button(enabled = !locked, onClick = {
            val l = loss.replace(',', '.').toDoubleOrNull()
            val m = maxT.toIntOrNull()
            val cd = cool.toIntOrNull()
            val s = hs.toIntOrNull()
            val e = he.toIntOrNull()
            val zoneOk = try { java.time.ZoneId.of(zone.trim()); true } catch (x: Exception) { false }
            if (l == null || l <= 0 || m == null || m < 1 || cd == null || cd < 1 ||
                s == null || e == null || s !in 0..23 || e !in 0..23 || !zoneOk
            ) {
                Toast.makeText(c, "Invalid value, please check the fields", Toast.LENGTH_SHORT).show()
            } else {
                Store.set(
                    c, "lossLimit" to l, "maxTrades" to m, "cooldownMin" to cd, "hStart" to s, "hEnd" to e,
                    "zone" to zone.trim(), "tLoss" to tLoss, "tTrades" to tTrades, "tCooldown" to tCool, "tHours" to tHours
                )
                Toast.makeText(c, "Saved", Toast.LENGTH_SHORT).show()
                Ui.bump()
            }
        }) { Text("Save settings") }
    }
}
