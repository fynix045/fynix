package com.tradelock.app

import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime

data class Lock(val reason: String, val endMs: Long)

object Engine {
    fun zone(c: Context): ZoneId =
        try { ZoneId.of(Store.str(c, "zone", "Asia/Jakarta")) } catch (e: Exception) { ZoneId.systemDefault() }

    private fun today(c: Context) = LocalDate.now(zone(c)).toString()

    private fun endOfDay(c: Context): Long {
        val z = zone(c)
        return LocalDate.now(z).plusDays(1).atStartOfDay(z).toInstant().toEpochMilli()
    }

    fun stats(c: Context): Pair<Double, Int> =
        if (Store.str(c, "day", "") != today(c)) 0.0 to 0
        else Store.num(c, "loss", 0.0) to Store.int(c, "trades", 0)

    fun current(c: Context): Lock? {
        val now = System.currentTimeMillis()
        val end = Store.long(c, "lockEnd")
        if (end > now) return Lock(Store.str(c, "lockReason", "Locked"), end)
        if (Store.bool(c, "tHours", false)) {
            val s = Store.int(c, "hStart", 20)
            val e = Store.int(c, "hEnd", 4)
            val zt = ZonedDateTime.now(zone(c))
            val h = zt.hour
            val inside = if (s == e) true else if (s < e) h in s until e else (h >= s || h < e)
            if (!inside) {
                var n = zt.withHour(s).withMinute(0).withSecond(0).withNano(0)
                if (!n.isAfter(zt)) n = n.plusDays(1)
                return Lock("Outside Trading Hours", n.toInstant().toEpochMilli())
            }
        }
        return null
    }

    fun lock(c: Context, reason: String, endMs: Long) {
        if (endMs > Store.long(c, "lockEnd")) Store.set(c, "lockEnd" to endMs, "lockReason" to reason)
    }

    fun emergency(c: Context, minutes: Long?) {
        val end = if (minutes == null) endOfDay(c) else System.currentTimeMillis() + minutes * 60_000
        lock(c, "Emergency Lock", end)
    }

    fun logTrade(c: Context, lossAmt: Double) {
        val (l, t) = stats(c)
        val nl = l + lossAmt
        val nt = t + 1
        Store.set(c, "day" to today(c), "loss" to nl, "trades" to nt)
        val limit = Store.num(c, "lossLimit", 100.0)
        if (Store.bool(c, "tLoss", true) && limit > 0 && nl >= limit)
            lock(c, "Daily Loss Limit Reached", endOfDay(c))
        if (Store.bool(c, "tTrades", true) && nt >= Store.int(c, "maxTrades", 3))
            lock(c, "Daily Trade Limit Reached", endOfDay(c))
        if (Store.bool(c, "tCooldown", true) && lossAmt > 0)
            lock(c, "Cooldown After Loss", System.currentTimeMillis() + Store.int(c, "cooldownMin", 60) * 60_000L)
    }

    fun a11yOn(c: Context): Boolean {
        val s = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val me = ComponentName(c, LockService::class.java)
        return s.split(':').any { ComponentName.unflattenFromString(it) == me }
    }

    fun appStatus(c: Context, pkg: String): String {
        val pm = c.packageManager
        return try {
            pm.getPackageInfo(pkg, 0)
            if (pm.getLaunchIntentForPackage(pkg) == null) "Incompatible (no launcher)" else "Installed"
        } catch (e: Exception) {
            "Not installed"
        }
    }

    fun fmt(ms: Long): String {
        val s = maxOf(0L, ms / 1000)
        return "%02d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
    }
}
