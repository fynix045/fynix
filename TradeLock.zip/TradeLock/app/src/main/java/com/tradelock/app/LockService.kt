package com.tradelock.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent

class LockService : AccessibilityService() {
    private var lastLaunch = 0L

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) return
        val app = Store.apps(this).firstOrNull { it.pkg == pkg && it.enabled } ?: return
        if (Engine.current(this) == null) return
        val t = SystemClock.elapsedRealtime()
        if (t - lastLaunch < 800) return
        lastLaunch = t
        performGlobalAction(GLOBAL_ACTION_HOME)
        startActivity(
            Intent(this, LockActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra("app", app.name)
        )
    }

    override fun onInterrupt() {}
}
