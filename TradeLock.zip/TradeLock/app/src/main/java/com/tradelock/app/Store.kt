package com.tradelock.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object Store {
    data class PApp(val pkg: String, val name: String, val enabled: Boolean)

    private fun sp(c: Context) = c.getSharedPreferences("tradelock", Context.MODE_PRIVATE)

    fun apps(c: Context): List<PApp> {
        val s = sp(c).getString("apps", null) ?: return listOf(
            PApp("net.metaquotes.metatrader5", "MetaTrader 5", true),
            PApp("com.tradingview.tradingviewapp", "TradingView", true)
        )
        val a = JSONArray(s)
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            PApp(o.getString("p"), o.getString("n"), o.getBoolean("e"))
        }
    }

    fun setApps(c: Context, l: List<PApp>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("p", it.pkg).put("n", it.name).put("e", it.enabled)) }
        sp(c).edit().putString("apps", a.toString()).commit()
    }

    fun str(c: Context, k: String, d: String): String = sp(c).getString(k, null) ?: d
    fun num(c: Context, k: String, d: Double): Double = sp(c).getString(k, null)?.toDoubleOrNull() ?: d
    fun int(c: Context, k: String, d: Int): Int = sp(c).getString(k, null)?.toIntOrNull() ?: d
    fun bool(c: Context, k: String, d: Boolean): Boolean = sp(c).getBoolean(k, d)
    fun long(c: Context, k: String): Long = sp(c).getLong(k, 0L)

    fun set(c: Context, vararg p: Pair<String, Any>) {
        val e = sp(c).edit()
        p.forEach { (k, v) ->
            when (v) {
                is Boolean -> e.putBoolean(k, v)
                is Long -> e.putLong(k, v)
                else -> e.putString(k, v.toString())
            }
        }
        e.commit()
    }
}
