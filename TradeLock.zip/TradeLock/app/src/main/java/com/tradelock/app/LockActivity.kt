package com.tradelock.app

import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

class LockActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) setShowWhenLocked(true)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {}
        })
        val app = intent.getStringExtra("app") ?: "Trading App"
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                LockScreen(
                    app,
                    onReturn = {
                        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        finish()
                    },
                    onExpired = { finish() }
                )
            }
        }
    }
}

@Composable
fun LockScreen(app: String, onReturn: () -> Unit, onExpired: () -> Unit) {
    val c = LocalContext.current
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var lock by remember { mutableStateOf(Engine.current(c)) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            lock = Engine.current(c)
            if (lock == null) { onExpired(); break }
            delay(1000)
        }
    }
    val l = lock
    Surface(color = Color(0xFF120000), contentColor = Color.White) {
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterVertically),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("TRADING LOCKED", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFF5252))
            Text("Reason: ${l?.reason ?: ""}")
            Text("Protected App: $app")
            Text("Status: LOCK ACTIVE", fontWeight = FontWeight.Bold)
            Text("Remaining Time: ${Engine.fmt((l?.endMs ?: now) - now)}", fontSize = 22.sp)
            Spacer(Modifier.height(8.dp))
            Text(
                "Your trading session has ended. Follow your risk management rules and return when the lock expires.",
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(16.dp))
            Button(onClick = onReturn) { Text("Return to TRADELOCK") }
        }
    }
}
