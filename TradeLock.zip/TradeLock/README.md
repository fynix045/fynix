# TRADELOCK
Android app lockdown for trading apps (MT5, TradingView + any launcher app).

## Build APK
**GitHub:** push this folder to a repo (branch main) -> Actions tab -> "Build APK" -> download artifact `TradeLock-debug-apk`.
**Android Studio:** open folder -> Build > Build APK(s). Output: app/build/outputs/apk/debug/app-debug.apk

## Setup on phone
Install APK -> Dashboard -> "Enable protection" -> turn on TRADELOCK in Accessibility settings.
